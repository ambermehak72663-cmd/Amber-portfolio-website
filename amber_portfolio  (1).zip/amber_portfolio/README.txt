Amber Mehak — Portfolio
-----------------------
This folder contains a ready-to-upload single-page portfolio website that matches your Canva design.
Replace placeholder images in assets/images/ with your exported Canva images (PNG/JPG) and update the Formspree action URL in index.html.

How to use:
1. Download and unzip.
2. Replace images in assets/images/ with your own (keep filenames or update HTML).
3. Replace assets/Amber_Mehak_CV.pdf with your CV.
4. Update Formspree endpoint in index.html (contact form).
5. Upload entire folder to GitHub repository root.
6. Enable GitHub Pages (Settings → Pages → main branch / root).
