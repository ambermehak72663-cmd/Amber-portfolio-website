// basic interactions
document.getElementById('year').textContent = new Date().getFullYear();
const menuToggle = document.getElementById('menuToggle');
menuToggle && menuToggle.addEventListener('click', () => {
  const nav = document.querySelector('.nav');
  if (nav) nav.classList.toggle('open');
});

// Contact form using Formspree (AJAX)
const contactForm = document.getElementById('contactForm');
const formStatus = document.getElementById('formStatus');
if (contactForm) {
  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    formStatus.textContent = 'Sending...';
    const data = new FormData(contactForm);
    const action = contactForm.getAttribute('action');
    try {
      const res = await fetch(action, { method: 'POST', body: data, headers: {'Accept':'application/json'} });
      if (res.ok) {
        formStatus.textContent = 'Message sent — thank you!';
        contactForm.reset();
      } else {
        const json = await res.json();
        formStatus.textContent = json?.error || 'Could not send message.';
      }
    } catch (err) {
      formStatus.textContent = 'Network error. Try again later.';
    }
  });
}
